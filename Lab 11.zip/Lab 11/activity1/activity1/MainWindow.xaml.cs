﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WpfImageShapes
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
           // InitializeComponent();

            // Create a Grid to hold shapes
            Grid grid = new Grid();

            // Circle (Ellipse)
            Ellipse ellipse = new Ellipse
            {
                Width = 200,
                Height = 200,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(50, 50, 0, 0),
                Fill = new ImageBrush
                {
                    ImageSource = new System.Windows.Media.Imaging.BitmapImage(
                        new System.Uri("Images/sample1.jpg", System.UriKind.Relative))
                }
            };
            grid.Children.Add(ellipse);

            // Rounded Rectangle
            Rectangle roundedRectangle = new Rectangle
            {
                Width = 200,
                Height = 200,
                RadiusX = 30,
                RadiusY = 30,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 50, 0, 0),
                Fill = new ImageBrush
                {
                    ImageSource = new System.Windows.Media.Imaging.BitmapImage(
                        new System.Uri("Images/sample2.jpg", System.UriKind.Relative))
                }
            };
            grid.Children.Add(roundedRectangle);

            // Regular Rectangle
            Rectangle rectangle = new Rectangle
            {
                Width = 200,
                Height = 200,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 50, 50, 0),
                Fill = new ImageBrush
                {
                    ImageSource = new System.Windows.Media.Imaging.BitmapImage(
                        new System.Uri("Images/sample3.jpg", System.UriKind.Relative))
                }
            };
            grid.Children.Add(rectangle);

            // Set Grid as Content
            this.Content = grid;
        }
    }
}
